"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
function on(channel, cb) {
    const listener = (_event, value) => cb(value);
    electron_1.ipcRenderer.on(channel, listener);
    return () => electron_1.ipcRenderer.off(channel, listener);
}
const api = {
    getConfig: () => electron_1.ipcRenderer.invoke('zvt:getConfig'),
    setConfig: (cfg) => electron_1.ipcRenderer.invoke('zvt:setConfig', cfg),
    setMode: (mode) => electron_1.ipcRenderer.invoke('zvt:setMode', mode),
    connectAndRegister: () => electron_1.ipcRenderer.invoke('zvt:connectAndRegister'),
    startPayment: (amountCents) => electron_1.ipcRenderer.invoke('zvt:startPayment', amountCents),
    cancelPayment: () => electron_1.ipcRenderer.invoke('zvt:cancelPayment'),
    reversal: (receiptNo) => electron_1.ipcRenderer.invoke('zvt:reversal', receiptNo),
    endOfDay: () => electron_1.ipcRenderer.invoke('zvt:endOfDay'),
    mockSetScenario: (s) => electron_1.ipcRenderer.invoke('zvt:mockSetScenario', s),
    mockGetStatus: () => electron_1.ipcRenderer.invoke('zvt:mockGetStatus'),
    onStatus: (cb) => on('zvt:status', cb),
    onLog: (cb) => on('zvt:log', cb),
    onPrintLine: (cb) => on('zvt:printLine', cb),
    onDisconnected: (cb) => on('zvt:disconnected', cb),
};
electron_1.contextBridge.exposeInMainWorld('zvt', api);
//# sourceMappingURL=preload.js.map