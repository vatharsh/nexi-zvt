import { contextBridge, ipcRenderer } from 'electron';
function on(channel, cb) {
    const listener = (_event, value) => cb(value);
    ipcRenderer.on(channel, listener);
    return () => ipcRenderer.off(channel, listener);
}
const api = {
    getConfig: () => ipcRenderer.invoke('zvt:getConfig'),
    setConfig: (cfg) => ipcRenderer.invoke('zvt:setConfig', cfg),
    setMode: (mode) => ipcRenderer.invoke('zvt:setMode', mode),
    connectAndRegister: () => ipcRenderer.invoke('zvt:connectAndRegister'),
    startPayment: (amountCents) => ipcRenderer.invoke('zvt:startPayment', amountCents),
    cancelPayment: () => ipcRenderer.invoke('zvt:cancelPayment'),
    reversal: (receiptNo) => ipcRenderer.invoke('zvt:reversal', receiptNo),
    endOfDay: () => ipcRenderer.invoke('zvt:endOfDay'),
    mockSetScenario: (s) => ipcRenderer.invoke('zvt:mockSetScenario', s),
    mockGetStatus: () => ipcRenderer.invoke('zvt:mockGetStatus'),
    onStatus: (cb) => on('zvt:status', cb),
    onLog: (cb) => on('zvt:log', cb),
    onPrintLine: (cb) => on('zvt:printLine', cb),
    onDisconnected: (cb) => on('zvt:disconnected', cb),
};
contextBridge.exposeInMainWorld('zvt', api);
//# sourceMappingURL=preload.js.map