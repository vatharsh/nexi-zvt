import { BrowserWindow, app, ipcMain } from 'electron';
import { mkdir, appendFile } from 'node:fs/promises';
import { join } from 'node:path';
import { MockTerminal } from '../mock/MockTerminal.js';
import { toHex } from './zvt/apdu.js';
import { ZvtClient } from './zvt/ZvtClient.js';
import { loadSettings, profileForMode, saveSettings } from './settings.js';
let settings;
let client;
let mock;
let operationMode = 'mock';
function send(channel, payload) {
    for (const win of BrowserWindow.getAllWindows()) {
        win.webContents.send(channel, payload);
    }
}
async function writeLog(line) {
    const dir = app.getPath('userData');
    const date = new Date().toISOString().slice(0, 10);
    await mkdir(dir, { recursive: true });
    await appendFile(join(dir, `zvt-${date}.log`), `${line}\n`);
}
function attachClientEvents(next) {
    next.on('log', (line) => {
        send('zvt:log', line);
        void writeLog(line);
    });
    next.on('status', (status) => send('zvt:status', status));
    next.on('printLine', (line) => send('zvt:printLine', line));
    next.on('disconnected', () => send('zvt:disconnected'));
}
function ensureClient() {
    const profile = profileForMode(settings, operationMode);
    if (!profile.host)
        throw new Error('Real terminal host is not configured');
    if (!client) {
        client = new ZvtClient(profile);
        attachClientEvents(client);
    }
    return client;
}
function resetClient() {
    client?.disconnect();
    client = undefined;
}
async function ensureMockState() {
    if (operationMode === 'mock') {
        mock ??= new MockTerminal();
        await mock.start();
        return;
    }
    if (mock) {
        await mock.stop();
        mock = undefined;
    }
}
function dto(result) {
    return {
        ...result,
        mode: operationMode,
        otherBmps: result.otherBmps.map((bmp) => ({ tag: bmp.tag, value: toHex(bmp.value) })),
        unparsedRemainder: result.unparsedRemainder ? toHex(result.unparsedRemainder) : undefined,
    };
}
async function runTransaction(fn) {
    const c = ensureClient();
    return dto(await fn(c));
}
export async function initializeIpc() {
    settings = await loadSettings();
    operationMode = settings.mode;
    await ensureMockState();
    ipcMain.handle('zvt:getConfig', async () => settings);
    ipcMain.handle('zvt:setConfig', async (_event, cfg) => {
        settings = cfg;
        operationMode = cfg.mode;
        resetClient();
        await saveSettings(settings);
        await ensureMockState();
    });
    ipcMain.handle('zvt:setMode', async (_event, mode) => {
        operationMode = mode;
        settings = { ...settings, mode };
        resetClient();
        await saveSettings(settings);
        await ensureMockState();
    });
    ipcMain.handle('zvt:connectAndRegister', async () => {
        try {
            const c = ensureClient();
            await c.connect();
            await c.register();
            return { ok: true };
        }
        catch (e) {
            return { ok: false, error: e.message };
        }
    });
    ipcMain.handle('zvt:startPayment', async (_event, amountCents) => runTransaction((c) => c.payment(amountCents)));
    ipcMain.handle('zvt:cancelPayment', async () => ensureClient().abort());
    ipcMain.handle('zvt:reversal', async (_event, receiptNo) => runTransaction((c) => c.reversal(receiptNo)));
    ipcMain.handle('zvt:endOfDay', async () => runTransaction((c) => c.endOfDay()));
    ipcMain.handle('zvt:mockSetScenario', async (_event, scenario) => {
        if (operationMode === 'real')
            throw new Error('Mock control is unavailable in Real mode');
        mock ??= new MockTerminal();
        await mock.start();
        mock.setScenario(scenario);
    });
    ipcMain.handle('zvt:mockGetStatus', async () => {
        if (operationMode === 'real')
            throw new Error('Mock control is unavailable in Real mode');
        mock ??= new MockTerminal();
        await mock.start();
        return mock.getStatus();
    });
}
export async function shutdownIpc() {
    resetClient();
    await mock?.stop();
}
//# sourceMappingURL=ipc.js.map