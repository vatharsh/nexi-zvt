/**
 * High-level ZVT client: owns the TCP socket to the terminal, frames/deframes
 * APDUs, ACKs terminal messages, and exposes promise-based commands.
 *
 * Designed to run in the Electron MAIN process only.
 */
import * as net from 'node:net';
import { EventEmitter } from 'node:events';
import { ApduAssembler, buildAck, buildApdu, isAck, isNack, toHex, ctrlHex, } from './apdu.js';
import { amountToBcd, digitStringToBcd, numberToBcd } from './bcd.js';
import { CMD, CURRENCY_EUR, DEFAULT_CONFIG_BYTE, errorText, intermediateStatusText, } from './constants.js';
import { parseStatusInformation } from './bmp.js';
/** Minimal CP437 -> unicode mapping for German receipt text. */
const CP437 = {
    0x81: 'ü', 0x84: 'ä', 0x8e: 'Ä', 0x94: 'ö', 0x99: 'Ö', 0x9a: 'Ü',
    0xe1: 'ß', 0xee: '€',
};
function decodeCp437(buf) {
    let s = '';
    for (const b of buf)
        s += b < 0x80 ? String.fromCharCode(b) : (CP437[b] ?? '?');
    return s;
}
export class ZvtClient extends EventEmitter {
    socket;
    assembler = new ApduAssembler();
    cfg;
    ackWaiter;
    completionWaiter;
    lastStatusInformation;
    lastStatusInformationRaw;
    receiptLines = [];
    busy = false;
    constructor(config) {
        super();
        this.cfg = {
            host: config.host,
            port: config.port ?? 20007,
            password: config.password ?? '000000',
            configByte: config.configByte ?? DEFAULT_CONFIG_BYTE,
            connectTimeoutMs: config.connectTimeoutMs ?? 5000,
            ackTimeoutMs: config.ackTimeoutMs ?? 5000,
            transactionTimeoutMs: config.transactionTimeoutMs ?? 90000,
        };
    }
    // ---------------------------------------------------------------- socket
    async connect() {
        if (this.socket && !this.socket.destroyed)
            return;
        await new Promise((resolve, reject) => {
            const socket = net.createConnection({ host: this.cfg.host, port: this.cfg.port });
            const timer = setTimeout(() => {
                socket.destroy();
                reject(new Error(`Connect timeout to ${this.cfg.host}:${this.cfg.port}`));
            }, this.cfg.connectTimeoutMs);
            socket.once('connect', () => {
                clearTimeout(timer);
                socket.setNoDelay(true);
                this.socket = socket;
                this.assembler.reset();
                socket.on('data', (chunk) => this.onData(chunk));
                socket.on('close', () => {
                    this.log('-- connection closed --');
                    this.failPending(new Error('Connection closed'));
                    this.emit('disconnected');
                });
                socket.on('error', (err) => this.log(`socket error: ${err.message}`));
                this.log(`connected to ${this.cfg.host}:${this.cfg.port}`);
                resolve();
            });
            socket.once('error', (err) => {
                clearTimeout(timer);
                reject(err);
            });
        });
    }
    disconnect() {
        this.socket?.destroy();
        this.socket = undefined;
    }
    send(frame) {
        if (!this.socket || this.socket.destroyed)
            throw new Error('Not connected');
        this.log(`ECR -> PT  ${toHex(frame)}`);
        this.socket.write(frame);
    }
    log(line) {
        this.emit('log', `[${new Date().toISOString()}] ${line}`);
    }
    // ------------------------------------------------------------- receiving
    onData(chunk) {
        let frames;
        try {
            frames = this.assembler.push(chunk);
        }
        catch (e) {
            this.log(`frame error: ${e.message}; resetting stream`);
            this.assembler.reset();
            return;
        }
        for (const apdu of frames)
            this.onApdu(apdu);
    }
    onApdu(apdu) {
        this.log(`PT -> ECR  ${toHex(apdu.raw)}`);
        if (isAck(apdu)) {
            this.settleAck();
            return;
        }
        if (isNack(apdu)) {
            const code = apdu.ctrl & 0xff;
            this.settleAck(new Error(`Terminal NACK: ${errorText(code)}`));
            return;
        }
        // Every command from the terminal must be acknowledged by the ECR.
        this.send(buildAck());
        switch (apdu.ctrl) {
            case CMD.INTERMEDIATE_STATUS: {
                const code = apdu.data[0] ?? 0;
                this.emit('status', { code, text: intermediateStatusText(code) });
                break;
            }
            case CMD.STATUS_INFORMATION: {
                this.lastStatusInformationRaw = apdu.data;
                this.lastStatusInformation = parseStatusInformation(apdu.data);
                if (this.lastStatusInformation.unparsedRemainder) {
                    this.log(`04 0F contained unknown BMPs, remainder: ${toHex(this.lastStatusInformation.unparsedRemainder)}`);
                }
                break;
            }
            case CMD.PRINT_LINE: {
                // data = 1 attribute byte + CP437 text
                const line = decodeCp437(apdu.data.subarray(1));
                this.receiptLines.push(line);
                this.emit('printLine', line);
                break;
            }
            case CMD.PRINT_TEXT_BLOCK: {
                this.log('received 06 D3 print text block (TLV) — stored raw');
                this.receiptLines.push(`[06D3] ${toHex(apdu.data)}`);
                break;
            }
            case CMD.COMPLETION:
            case CMD.ABORT_FROM_PT: {
                this.settleCompletion(apdu);
                break;
            }
            default:
                this.log(`unhandled command ${ctrlHex(apdu.ctrl)} — acknowledged and ignored`);
        }
    }
    // -------------------------------------------------------------- waiting
    waitForAck() {
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                this.ackWaiter = undefined;
                reject(new Error('Timeout waiting for terminal ACK'));
            }, this.cfg.ackTimeoutMs);
            this.ackWaiter = { resolve, reject, timer };
        });
    }
    settleAck(err) {
        const w = this.ackWaiter;
        if (!w)
            return;
        this.ackWaiter = undefined;
        clearTimeout(w.timer);
        err ? w.reject(err) : w.resolve();
    }
    waitForCompletion(timeoutMs) {
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                this.completionWaiter = undefined;
                reject(new Error('Timeout waiting for completion from terminal'));
            }, timeoutMs);
            this.completionWaiter = { resolve, reject, timer };
        });
    }
    settleCompletion(apdu) {
        const w = this.completionWaiter;
        if (!w)
            return;
        this.completionWaiter = undefined;
        clearTimeout(w.timer);
        w.resolve(apdu);
    }
    failPending(err) {
        this.settleAck(err);
        const w = this.completionWaiter;
        if (w) {
            this.completionWaiter = undefined;
            clearTimeout(w.timer);
            w.reject(err);
        }
    }
    /** Send a command, await terminal ACK, then await Completion/Abort. */
    async transact(ctrl, data, timeoutMs) {
        if (this.busy)
            throw new Error('Another ZVT command is in progress');
        this.busy = true;
        try {
            await this.connect();
            this.lastStatusInformation = undefined;
            this.lastStatusInformationRaw = undefined;
            this.receiptLines = [];
            const completion = this.waitForCompletion(timeoutMs);
            const ack = this.waitForAck();
            this.send(buildApdu(ctrl, data));
            await ack;
            return await completion;
        }
        finally {
            this.busy = false;
        }
    }
    buildPaymentResult(finalApdu) {
        const info = this.lastStatusInformation ?? { approved: false, otherBmps: [] };
        const aborted = finalApdu.ctrl === CMD.ABORT_FROM_PT;
        if (aborted) {
            const code = finalApdu.data[0] ?? 0x6c;
            info.approved = false;
            info.resultCode = info.resultCode ?? code;
            info.resultText = info.resultText ?? errorText(code);
        }
        return {
            ...info,
            merchantReceipt: [...this.receiptLines],
            customerReceipt: [], // split by print attributes if needed
            rawStatusInformation: this.lastStatusInformationRaw
                ? toHex(this.lastStatusInformationRaw)
                : undefined,
        };
    }
    // -------------------------------------------------------------- commands
    /** Registration 06 00 — run once after connecting. */
    async register() {
        const data = Buffer.concat([
            digitStringToBcd(this.cfg.password), // 3 bytes
            Buffer.from([this.cfg.configByte]),
            CURRENCY_EUR,
        ]);
        const completion = await this.transact(CMD.REGISTRATION, data, 15000);
        if (completion.ctrl === CMD.ABORT_FROM_PT) {
            throw new Error(`Registration aborted: ${errorText(completion.data[0] ?? 0)}`);
        }
        this.log('registration complete');
    }
    /** Authorization 06 01 — start a card payment. Amount in euro-cents. */
    async payment(amountCents) {
        const data = Buffer.concat([
            Buffer.from([0x04]),
            amountToBcd(amountCents),
            Buffer.from([0x49]),
            CURRENCY_EUR,
        ]);
        const completion = await this.transact(CMD.AUTHORIZATION, data, this.cfg.transactionTimeoutMs);
        return this.buildPaymentResult(completion);
    }
    /** Reversal 06 30 of a same-day transaction by its receipt number. */
    async reversal(receiptNo) {
        const data = Buffer.concat([
            digitStringToBcd(this.cfg.password),
            Buffer.from([0x87]),
            numberToBcd(receiptNo, 2),
        ]);
        const completion = await this.transact(CMD.REVERSAL, data, this.cfg.transactionTimeoutMs);
        return this.buildPaymentResult(completion);
    }
    /** End-of-day 06 50 (Kassenschnitt). */
    async endOfDay() {
        const data = digitStringToBcd(this.cfg.password);
        const completion = await this.transact(CMD.END_OF_DAY, data, 120000);
        return this.buildPaymentResult(completion);
    }
    /** Abort 06 B0 — cancel a running payment from the ECR side. */
    async abort() {
        // Deliberately not using transact(): abort is sent while busy.
        await this.connect();
        const ack = this.waitForAck();
        this.send(buildApdu(CMD.ABORT));
        await ack;
    }
}
//# sourceMappingURL=ZvtClient.js.map