import * as net from 'node:net';
import { EventEmitter } from 'node:events';
import { ApduAssembler, buildAck, buildApdu, isAck, toHex } from '../electron/zvt/apdu.js';
import { amountToBcd, bcdToAmountCents, numberToBcd } from '../electron/zvt/bcd.js';
import { CMD } from '../electron/zvt/constants.js';
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
export class MockTerminal extends EventEmitter {
    server;
    host;
    port;
    fixtureSink;
    scenario;
    sessions = new Set();
    traceNo = 40;
    receiptNo = 6;
    constructor(options = {}) {
        super();
        this.host = options.host ?? '127.0.0.1';
        this.port = options.port ?? 20007;
        this.scenario = options.scenario ?? 'approve';
        this.fixtureSink = options.fixtureSink;
    }
    async start() {
        if (this.server?.listening)
            return;
        this.server = net.createServer((socket) => this.onConnection(socket));
        await new Promise((resolve, reject) => {
            this.server.once('error', reject);
            this.server.listen(this.port, this.host, () => {
                this.server.off('error', reject);
                resolve();
            });
        });
    }
    async stop() {
        for (const session of this.sessions)
            session.socket.destroy();
        this.sessions.clear();
        if (!this.server)
            return;
        await new Promise((resolve) => this.server.close(() => resolve()));
        this.server = undefined;
    }
    setScenario(scenario) {
        this.scenario = scenario;
    }
    getStatus() {
        return {
            running: Boolean(this.server?.listening),
            scenario: this.scenario,
            connections: this.sessions.size,
        };
    }
    onConnection(socket) {
        socket.setNoDelay(true);
        const session = {
            socket,
            assembler: new ApduAssembler(),
            ackWaiters: [],
            closed: false,
        };
        this.sessions.add(session);
        socket.on('data', (chunk) => this.onData(session, chunk));
        socket.on('close', () => {
            session.closed = true;
            for (const resolve of session.ackWaiters.splice(0))
                resolve();
            this.sessions.delete(session);
        });
        socket.on('error', () => undefined);
    }
    onData(session, chunk) {
        let apdus;
        try {
            apdus = session.assembler.push(chunk);
        }
        catch {
            session.assembler.reset();
            void this.writeFrame(session, buildApdu(0x849a));
            return;
        }
        for (const apdu of apdus) {
            this.emit('log', `ECR -> PT ${toHex(apdu.raw)}`);
            if (isAck(apdu)) {
                session.ackWaiters.shift()?.();
                continue;
            }
            void this.handleCommand(session, apdu);
        }
    }
    async handleCommand(session, apdu) {
        switch (apdu.ctrl) {
            case CMD.REGISTRATION:
                await this.writeFrame(session, buildAck());
                await this.sendTerminalMessage(session, CMD.COMPLETION);
                break;
            case CMD.AUTHORIZATION:
                await this.handleAuthorization(session, apdu);
                break;
            case CMD.REVERSAL:
            case CMD.END_OF_DAY:
                await this.writeFrame(session, buildAck());
                await this.sendTerminalMessage(session, CMD.STATUS_INFORMATION, this.statusPayload(0, 0));
                await this.sendTerminalMessage(session, CMD.COMPLETION);
                break;
            case CMD.ABORT:
                await this.writeFrame(session, buildAck());
                await this.sendTerminalMessage(session, CMD.ABORT_FROM_PT, Buffer.from([0x6c]));
                break;
            default:
                await this.writeFrame(session, buildAck());
                await this.sendTerminalMessage(session, CMD.ABORT_FROM_PT, Buffer.from([0x9a]));
        }
    }
    async handleAuthorization(session, apdu) {
        const scenario = this.scenario;
        const amount = this.extractAmount(apdu.data);
        await this.writeFrame(session, buildAck());
        if (scenario === 'timeout')
            return;
        if (scenario === 'drop') {
            await delay(250);
            session.socket.destroy();
            return;
        }
        await delay(300);
        await this.sendTerminalMessage(session, CMD.INTERMEDIATE_STATUS, Buffer.from([0x0a]));
        await delay(scenario === 'slow' ? 2200 : 500);
        await this.sendTerminalMessage(session, CMD.INTERMEDIATE_STATUS, Buffer.from([0x04]));
        if (scenario === 'slow') {
            await delay(1800);
            await this.sendTerminalMessage(session, CMD.INTERMEDIATE_STATUS, Buffer.from([0x0e]));
            await delay(2600);
            await this.sendTerminalMessage(session, CMD.INTERMEDIATE_STATUS, Buffer.from([0x41]));
        }
        else {
            await delay(700);
        }
        if (scenario === 'decline' || scenario === 'decline-expired') {
            const code = scenario === 'decline-expired' ? 0x78 : 0x6c;
            await this.sendTerminalMessage(session, CMD.STATUS_INFORMATION, this.statusPayload(amount, code));
            await this.sendTerminalMessage(session, CMD.ABORT_FROM_PT, Buffer.from([code]));
            return;
        }
        await this.sendTerminalMessage(session, CMD.STATUS_INFORMATION, this.statusPayload(amount, 0x00));
        await this.sendTerminalMessage(session, CMD.PRINT_LINE, this.printLine('Nexi Germany Test'));
        await this.sendTerminalMessage(session, CMD.PRINT_LINE, this.printLine(`Betrag EUR ${this.formatAmount(amount)}`));
        await this.sendTerminalMessage(session, CMD.COMPLETION);
    }
    async sendTerminalMessage(session, ctrl, data = Buffer.alloc(0)) {
        const ack = this.waitForEcrAck(session);
        await this.writeFrame(session, buildApdu(ctrl, data));
        await ack;
    }
    waitForEcrAck(session) {
        if (session.closed)
            return Promise.resolve();
        return new Promise((resolve) => {
            const timer = setTimeout(resolve, 5000);
            session.ackWaiters.push(() => {
                clearTimeout(timer);
                resolve();
            });
        });
    }
    async writeFrame(session, frame) {
        if (session.closed || session.socket.destroyed)
            return;
        this.fixtureSink?.(frame);
        this.emit('log', `PT -> ECR ${toHex(frame)}`);
        const chunks = this.split(frame);
        for (const chunk of chunks) {
            if (session.closed || session.socket.destroyed)
                return;
            session.socket.write(chunk);
            await delay(5 + Math.floor(Math.random() * 16));
        }
    }
    split(frame) {
        if (frame.length <= 2)
            return [frame];
        const pieces = 1 + Math.floor(Math.random() * Math.min(3, frame.length));
        if (pieces === 1)
            return [frame];
        const chunks = [];
        let offset = 0;
        for (let i = 0; i < pieces - 1; i++) {
            const remaining = frame.length - offset;
            const size = 1 + Math.floor(Math.random() * Math.max(1, remaining - (pieces - i - 1)));
            chunks.push(frame.subarray(offset, offset + size));
            offset += size;
        }
        chunks.push(frame.subarray(offset));
        return chunks;
    }
    extractAmount(data) {
        for (let i = 0; i < data.length; i++) {
            if (data[i] === 0x04 && i + 6 < data.length) {
                return bcdToAmountCents(data.subarray(i + 1, i + 7));
            }
        }
        return 0;
    }
    statusPayload(amountCents, resultCode) {
        if (resultCode === 0x00) {
            this.traceNo += 1;
            this.receiptNo += 1;
        }
        return Buffer.concat([
            Buffer.from([0x27, resultCode]),
            Buffer.from([0x04]),
            amountToBcd(Math.max(1, amountCents || 1)),
            Buffer.from([0x0b]),
            numberToBcd(this.traceNo, 3),
            Buffer.from([0x87]),
            numberToBcd(this.receiptNo, 2),
            Buffer.from([0x8a, 0x05]),
            Buffer.from([0x22, 0xf0, 0xf4, 0x54, 0x13, 0xee, 0xee]),
            Buffer.from([0x29, 0x12, 0x34, 0x56, 0x78]),
        ]);
    }
    printLine(text) {
        return Buffer.concat([Buffer.from([0x00]), Buffer.from(text, 'latin1')]);
    }
    formatAmount(amountCents) {
        const euros = Math.floor(amountCents / 100);
        const cents = String(amountCents % 100).padStart(2, '0');
        return `${euros},${cents}`;
    }
}
//# sourceMappingURL=MockTerminal.js.map