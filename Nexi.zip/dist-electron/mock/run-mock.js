import { createInterface } from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';
import { MockTerminal } from './MockTerminal.js';
const scenarios = ['approve', 'decline', 'decline-expired', 'timeout', 'slow', 'drop'];
function readScenario() {
    const flag = process.argv.find((arg) => arg.startsWith('--') && scenarios.includes(arg.slice(2)));
    return flag ? flag.slice(2) : 'approve';
}
const terminal = new MockTerminal({ scenario: readScenario() });
terminal.on('log', (line) => console.log(line));
await terminal.start();
console.log(`Mock ZVT terminal listening on 127.0.0.1:20007 (${terminal.getStatus().scenario})`);
console.log(`Type one of: ${scenarios.join(', ')}; or "status", "quit".`);
const rl = createInterface({ input, output });
for await (const line of rl) {
    const cmd = line.trim();
    if (cmd === 'quit' || cmd === 'exit')
        break;
    if (cmd === 'status') {
        console.log(JSON.stringify(terminal.getStatus()));
        continue;
    }
    if (scenarios.includes(cmd)) {
        terminal.setScenario(cmd);
        console.log(`scenario=${cmd}`);
    }
    else {
        console.log(`unknown command: ${cmd}`);
    }
}
await terminal.stop();
//# sourceMappingURL=run-mock.js.map